({
	doInit : function(component, event, helper) {
		
        var action = component.get("c.getActiveUsers");
        action.setCallback(this, function(a) {
            component.set("v.userlist", a.getReturnValue());
        });
        $A.enqueueAction(action);
        
        var action2 = component.get("c.getLeadReasgnVal");
        action2.setCallback(this, function(a) {
            component.set("v.leadRsgRsn", a.getReturnValue());
        });
        $A.enqueueAction(action2);
        
        var action3 = component.get("c.getLeadStatusVal");
        action3.setCallback(this, function(a) {
            component.set("v.leadStatus", a.getReturnValue());
        });
        $A.enqueueAction(action3);
        
        var currentObject = component.get("v.ObjectName");        
        if(currentObject == "Lead"){
            component.set("v.isLead", true);
        }
	},
    
    searchUser : function (component, event, helper){
        var cmp = component.find("crntusr");
        $A.util.removeClass(cmp, "hide");
        $A.util.addClass(cmp, "show");
        
        var usrlist = component.get("v.userlist");
        var searchstring = document.getElementById("usrlookup").value;
        var searchresult = [];
        
        if(searchstring == null || searchstring == ''){
            $A.util.addClass(cmp, "hide");
            $A.util.removeClass(cmp, "show");
            document.getElementById("usrlkpval").value = '';
        }
        
        for(var i = 0; i < usrlist.length; i++){
            if(usrlist[i].Name.indexOf(searchstring) > -1 || usrlist[i].Name.toLowerCase().indexOf(searchstring.toLowerCase()) > -1){            
                searchresult.push(usrlist[i]);
            }
        }
        component.set("v.searchres", searchresult);
    },
    
    assignUser : function (component, event, helper){
        var src = event.srcElement;
        document.getElementById("usrlkpval").value = src.id;
        document.getElementById("usrlookup").value = src.dataset.target;
        
        var cmp = component.find("crntusr");
        $A.util.addClass(cmp, "hide");
        $A.util.removeClass(cmp, "show");
    },
    
    searchnewUser : function (component, event, helper){
        var cmp = component.find("newusr");
        $A.util.removeClass(cmp, "hide");
        $A.util.addClass(cmp, "show");
        
        var usrlist = component.get("v.userlist");
        var searchstring = document.getElementById("newusrlookup").value;
        var searchresult = [];
        
        if(searchstring == null || searchstring == ''){
            $A.util.addClass(cmp, "hide");
            $A.util.removeClass(cmp, "show");
            document.getElementById("newusrlkpval").value = '';
        }
        
        for(var i = 0; i < usrlist.length; i++){
            if(usrlist[i].Name.indexOf(searchstring) > -1 || usrlist[i].Name.toLowerCase().indexOf(searchstring.toLowerCase()) > -1){            
                searchresult.push(usrlist[i]);
            }
        }
        component.set("v.newsearchres", searchresult);
    },
    
    assignnewUser : function (component, event, helper){
        var src = event.srcElement;
        document.getElementById("newusrlkpval").value = src.id;
        document.getElementById("newusrlookup").value = src.dataset.target;
        
        var cmp = component.find("newusr");
        $A.util.addClass(cmp, "hide");
        $A.util.removeClass(cmp, "show");
    },
    
    reassignRecords : function (component, event, helper){
    	console.log('inside reassign');
        var currentUserId = document.getElementById("usrlkpval").value;
        var newUserId = document.getElementById("newusrlkpval").value;
        var reassignmentReason;
        var lead_Status;
        console.log('currentUserId is:=='+currentUserId);
		
        if (currentUserId == '' || currentUserId == null) {
          //  helper.validateUserId(component, event, helper);
            var exc = component.find("reAssignError");
            $A.util.removeClass(exc, "hide");
        } 
        else{
            var currentObject = component.get("v.ObjectName");        
            if(currentObject == "Lead"){
                var ld = component.get("v.lead");            
                reassignmentReason = component.find("rsn").get("v.value");
                lead_Status = component.find("rsnLeadStatus").get("v.value");
            }
            var action2 = component.get("c.reassignRecord");
            action2.setParams({
                "objName": component.get("v.ObjectName"),
                "currentUser" : currentUserId,
                "newUser" : newUserId,
                "reassignReason" : reassignmentReason,
                "leadStatus" : lead_Status
                
            });
            action2.setCallback(this, function(a) {
                window.history.back();
            });
            $A.enqueueAction(action2);
        }
    },
    
    cancel : function(component, event, helper){
        window.history.back();
    }
    
})