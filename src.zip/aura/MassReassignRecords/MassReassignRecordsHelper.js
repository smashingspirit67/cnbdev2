({    
    validateUserId: function(cmp, evt, helper) {
        console.log('is invoked helper');        
    	var stat = cmp.find("rsn").get("v.value");
        
        var currentUserId = document.getElementById("usrlkpval").value;
        console.log('is invoked helper1'+$A.util.isUndefinedOrNull(newUserId));
        var newUserId = document.getElementById("newusrlkpval").value;
    	$A.log("Errors exists"+$A.util.isUndefinedOrNull(newUserId));
        if ($A.util.isUndefinedOrNull(newUserId)){
            var exc = cmp.find("reAssignError");
            $A.util.removeClass(exc, "hide");
        }
        $A.enqueueAction(action);
		console.log('is invoked helper ended');
    }


})