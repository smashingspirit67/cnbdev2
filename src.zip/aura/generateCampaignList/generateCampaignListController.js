({
	doInit : function(component, event, helper) {
        console.log("===="+component);
        var action1 = component.get("c.init");
            action1.setParams({
                "campaignMemberId": component.get("v.recordIds")
            });
        action1.setCallback(this, function(a) {
               // window.history.back();
            component.set("v.accounts", a.getReturnValue());
            var accountList=component.get("v.accounts");
            if(accountList!=null){
                component.set("v.msg", "Select Accounts to create/delete Campaign List records for this contact.");
            }else{
                component.set("v.msg", "You cannot select Account of Lead campaign memeber. Press Cancel to go back.");
            }
            });
        $A.enqueueAction(action1); 
	},
    doSave : function(component, event, helper) {
        var test=component.get("v.accounts");
         console.log("===test="+test);
    	for(var obj in test){
            var value=document.getElementById(test[obj].accountId).checked;
            console.log("===value="+value);
            test[obj].isAlready=value;
            console.log("===obj="+test[obj].isAlready);   
        }
    	console.log("===component.get(v.accounts)="+JSON.stringify(component.get("v.accounts")));
         var action1 = component.get("c.createIndirectCampaignList");
            action1.setParams({
                "accountWrapperList": JSON.stringify(component.get("v.accounts")),
                "campaignMemberId": component.get("v.recordIds")
            });
        action1.setCallback(this, function(a) {
            console.log(JSON.stringify(a.getReturnValue()));
			window.history.back();
            });
            $A.enqueueAction(action1);
        
    	//console.log("===selected="+selected);
	},
    viewRecord : function (component, event, helper) {
        window.history.back();
	}
})