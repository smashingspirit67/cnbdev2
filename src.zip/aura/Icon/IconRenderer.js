({
  render: function(component, helper) {
    //grab attributes from the component markup
    var classname = component.get("v.class");
    var xlinkhref = component.get("v.xlinkHref");
    var ariaHidden = component.get("v.ariaHidden");
	var pngPath    = component.get("v.pngPath"); 
      
	var ua = window.navigator.userAgent;
    var msie = ua.indexOf ( "MSIE " );
	var  ieCheck = false;
 
    if ( msie > 0  || !!navigator.userAgent.match(/Trident.*rv\:11\./) ) {
        //alert(parseInt (ua.substring (msie+5, ua.indexOf (".", msie ))));
        ieCheck = true;
   	}	  

	if(ieCheck == true) {
        //return an img element w/ the attributes
        //var iconIndex = xlinkhref.lastIndexOf('#');
		//var icon1 = xlinkhref.substring(iconIndex + 1);
        var img = document.createElement("img");
        img.setAttribute('class', classname);
        //img.setAttribute('aria-hidden', ariaHidden);
		img.setAttribute('src', pngPath);
        return img;
       }      
      else{
        //return an svg element w/ the attributes
        var svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
        svg.setAttribute('class', classname);
        svg.setAttribute('aria-hidden', false);
        svg.innerHTML = '<use xlink:href="'+xlinkhref+'"></use>';
        return svg;          
      } 
  }
       
})