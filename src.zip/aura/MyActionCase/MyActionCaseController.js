({
     "Submit" : function(component, event, helper) {    
		//Get All data from component
        var desc = component.find("Description").get("v.value");     
        var caseType = component.find("contactName").get("v.value");        
        var sobj = component.get("v.sobjecttype"); 
        var fileInput = component.find("file").getElement();
        var file = fileInput.files[0];
        var fr = new FileReader();      
		//File Content Conversion to encode in system expected format	
		//If Attachment found
        if(file != null)
		{             
			fr.onload = function() {
				var fileContents = fr.result;
				var base64Mark = 'base64,';
				var dataStart = fileContents.indexOf(base64Mark) + base64Mark.length;
				fileContents = fileContents.substring(dataStart);
				//Setting the parameters to Apex controller to insert case/attachment
				var action = component.get("c.submitCaseRequest");                    
				 action.setParams({
					Description: desc,  
					caseType:caseType,
					sobjec: sobj,
					recId: component.get("v.recordId"),
					fileName: file.name,
					base64Data: encodeURIComponent(fileContents), 
					contentType: file.type
				});     
				//Once data inserted in case then success message shows here            
				action.setCallback(this, function(response) {
				var res = response.getReturnValue();                     
				var toastEvent = $A.get("e.force:showToast");
				toastEvent.setParams({
						mode: 'sticky',
						message: 'Case was',
						messageTemplate: ' {0} created! See it {1}!',
						messageTemplateData: ['Case was', {
						url: '/500/o',
						label: 'here',
						}
					  ]                 
					});
				toastEvent.fire();            
				$A.get("e.force:refreshView").fire();
				//Close the model window
				var dismissActionPanel = $A.get("e.force:closeQuickAction");
				dismissActionPanel.fire();
				});
			   $A.enqueueAction(action);
			}		             
			fr.readAsDataURL(file);
		}
		//If Attachment not found
        else if(file == null)
		{             
            var action = component.get("c.submitCaseRequestWOAttach");
            action.setParams({
                    Description: desc,  
                    caseType:caseType,
                    sobjec: sobj,
                    recId: component.get("v.recordId")
                  });
            action.setCallback(this, function(response) {
            var res = response.getReturnValue();  			               
            var toastEvent = $A.get("e.force:showToast");
                 toastEvent.setParams({
                    mode: 'sticky',
                    message: 'Case was',
                    messageTemplate: ' {0} created! See it {1}!',
                    messageTemplateData: ['Case was', {
                    url: '/500/o',
                    label: 'here',
                    }
                  ]                 
                });
               
                toastEvent.fire();            
                $A.get("e.force:refreshView").fire();
                var dismissActionPanel = $A.get("e.force:closeQuickAction");
                dismissActionPanel.fire();
            });
             $A.enqueueAction(action);
        }
      
    }
})