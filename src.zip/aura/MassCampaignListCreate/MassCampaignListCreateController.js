({
	doInit : function(component, event, helper) {
        console.log("===1="+component.get("v.recordId"));
        var action1 = component.get("c.init");
            action1.setParams({
                "campaignId": component.get("v.recordId")
            });
        action1.setCallback(this, function(a) {
            component.set("v.accounts", a.getReturnValue());
            console.log(JSON.stringify(a.getReturnValue()));
            var test = a.getReturnValue();
            var isSelect = false;
            for(var con in test){
                var head=test[con];
                for(var obj in head.accountList){
                    var isTrue = head.accountList[obj].isAlready;
                    if(isTrue != true ){
                        isSelect=true;
                        break;
                    }
                }
            }
            if(isSelect){
                component.set("v.select", "Select All");
            }else{
                component.set("v.select", "Deselect All");
            }
        });
        var action2 = component.get("c.selectAllbuttonVisibility");
        action2.setCallback(this, function(a) {
            console.log("=1==a.getReturnValue()="+a.getReturnValue());
            component.set("v.selecAllVisibility", a.getReturnValue());
        });
        $A.enqueueAction(action2);
        $A.enqueueAction(action1); 
	},
    doSave1 : function(component, event, helper) {
        var test=component.get("v.accounts");
         console.log("===test="+test);
    	for(var con in test){
            var head=test[con];
            for(var obj in head.accountList){
                var value=document.getElementById(head.contactId+'-'+head.accountList[obj].accountId).checked;
                console.log("===value="+value);
                head.accountList[obj].isAlready=value;
            }
        }
    	console.log("===component.get(v.accounts)="+JSON.stringify(component.get("v.accounts")));
         var action1 = component.get("c.doSave");
            action1.setParams({
                "contactWrapperList": JSON.stringify(component.get("v.accounts")),
                "campaignId": component.get("v.recordId")
            });
        action1.setCallback(this, function(a) {
            var navEvt = $A.get("e.force:navigateToSObject");
            navEvt.setParams({
              "recordId": component.get("v.recordId"),
              "slideDevName": "detail"
            });
            navEvt.fire();
            });
        $A.enqueueAction(action1);
	},
    viewRecord : function (component, event, helper) {
        var navEvt = $A.get("e.force:navigateToSObject");
            navEvt.setParams({
              "recordId": component.get("v.recordId"),
              "slideDevName": "detail"
            });
            navEvt.fire();
	},
    selectAll : function (component, event, helper) {
        var select = component.get("v.select");
        var test=component.get("v.accounts");
        if(select == 'Select All'){
            for(var con in test){
                var head=test[con];
                for(var obj in head.accountList){
                    head.accountList[obj].isAlready=true;
                }
            }
            component.set("v.select", "Deselect All");
        }else{
            for(var con in test){
                var head=test[con];
                for(var obj in head.accountList){
                    head.accountList[obj].isAlready=false;
                }
            }
            component.set("v.select", "Select All");
        }
        component.set("v.accounts", test);
    },
    buttonLabelChange : function (component, event, helper) {
        var test=component.get("v.accounts");
        var isSelect=false;
        for(var con in test){
            var head=test[con];
            for(var obj in head.accountList){
                 var value=document.getElementById(head.contactId+'-'+head.accountList[obj].accountId).checked;
                    if(value != true){
                        isSelect=true;
                        break;
                    }
            }
        }
        if(isSelect){
            component.set("v.select", "Select All");
        }else{
            component.set("v.select", "Deselect All");
        }
    }
})