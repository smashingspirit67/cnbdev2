({
	doInit : function(component, event, helper) {
        
        var getRecordType = component.get("c.getProfilerecordTypeName");
        getRecordType.setParams( {
            "recordId": component.get("v.recordId"),
        });
        getRecordType.setCallback(this, function(a) {                          	
            console.log('RecordTypeName is:'+JSON.stringify(a.getReturnValue()));      
            component.set("v.profilerecordTypeName", a.getReturnValue());                     
        });
        
        
        var initiateRealStateAction = component.get("c.initiate");
        initiateRealStateAction.setParams( {
            "recordId": component.get("v.recordId"),
            "objectName": "Real_Estate_Schedule__c",
            "whereColumn":  "Profile__c"
        });
        initiateRealStateAction.setCallback(this, function(a) {                          	
            console.log('Real Estate is:'+JSON.stringify(a.getReturnValue()));      
            component.set("v.RealEstateScheduleListRecords", a.getReturnValue());                     
        });
		
		var initiateStaffAction = component.get("c.initiate");
        initiateStaffAction.setParams( {
            "recordId": component.get("v.recordId"),
            "objectName": "Staff__c",
            "whereColumn":  "Profile__c"
        });
        initiateStaffAction.setCallback(this, function(a) {                          	
            console.log('Staff is:'+JSON.stringify(a.getReturnValue()));      
            component.set("v.StaffListRecords", a.getReturnValue());                     
        });        
        
        
		var initiateAssetScheduleAction = component.get("c.initiate");
        initiateAssetScheduleAction.setParams( {
            "recordId": component.get("v.recordId"),
            "objectName": "Asset_Schedule__c",
            "whereColumn":  "Profile__c"
        });
        initiateAssetScheduleAction.setCallback(this, function(a) {                          	
            console.log('Asset Schedule is:'+JSON.stringify(a.getReturnValue()));      
            component.set("v.AssetScheduleListRecords", a.getReturnValue());                     
        });
        
        var initiateBeneficiaryAction = component.get("c.initiate");
        initiateBeneficiaryAction.setParams( {
            "recordId": component.get("v.recordId"),
            "objectName": "Beneficiaries__c",
            "whereColumn":  "Profile__c"
        });
        initiateBeneficiaryAction.setCallback(this, function(a) {                          	
            console.log('Beneficiary is:'+JSON.stringify(a.getReturnValue()));      
            component.set("v.BeneficiariesListRecords", a.getReturnValue());                     
        });
        
        var initiateBussDebtAction = component.get("c.initiate");
        initiateBussDebtAction.setParams( {
            "recordId": component.get("v.recordId"),
            "objectName": "Business_Debt_Schedule__c",
            "whereColumn":  "Profile__c"
        });
        initiateBussDebtAction.setCallback(this, function(a) {                          	
            console.log('Business Debt is:'+JSON.stringify(a.getReturnValue()));      
            component.set("v.BusinessDebtListRecords", a.getReturnValue());                     
        });
        
        var initiateFamilyAction = component.get("c.initiate");
        initiateFamilyAction.setParams( {
            "recordId": component.get("v.recordId"),
            "objectName": "Family__c",
            "whereColumn":  "Profile__c"
        });
        initiateFamilyAction.setCallback(this, function(a) {                          	
            console.log('Family is:'+JSON.stringify(a.getReturnValue()));      
            component.set("v.FamilyListRecords", a.getReturnValue());                     
        });
        
        var initiateInsuranceAction = component.get("c.initiate");
        initiateInsuranceAction.setParams( {
            "recordId": component.get("v.recordId"),
            "objectName": "Insurance__c",
            "whereColumn":  "Profile__c"
        });
        initiateInsuranceAction.setCallback(this, function(a) {                          	
            console.log('Family is:'+JSON.stringify(a.getReturnValue()));      
            component.set("v.InsuranceListRecords", a.getReturnValue());                     
        });
        
        var initiateMaritalAction = component.get("c.initiate");
        initiateMaritalAction.setParams( {
            "recordId": component.get("v.recordId"),
            "objectName": "Marital__c",
            "whereColumn":  "Profile__c"
        });
        initiateMaritalAction.setCallback(this, function(a) {                          	
            console.log('Family is:'+JSON.stringify(a.getReturnValue()));      
            component.set("v.MaritalListRecords", a.getReturnValue());                     
        });
        
        var initiateProfile = component.get("c.getProfileId");
        initiateProfile.setParams({
            "recordId":component.get("v.recordId")
       	});
        initiateProfile.setCallback(this,function(a) {
            component.set("v.profileRecordId",a.getReturnValue());
            console.log('profileRecordId  is:'+JSON.stringify(a.getReturnValue()));
        });
        $A.enqueueAction(getRecordType); 
        $A.enqueueAction(initiateProfile); 
        $A.enqueueAction(initiateRealStateAction);
        $A.enqueueAction(initiateAssetScheduleAction);  
        $A.enqueueAction(initiateBeneficiaryAction);  
        $A.enqueueAction(initiateBussDebtAction);  
        $A.enqueueAction(initiateFamilyAction);  
        $A.enqueueAction(initiateInsuranceAction); 
        $A.enqueueAction(initiateStaffAction); 
        $A.enqueueAction(initiateMaritalAction);  
        
        
    },
    
    /*gotoAssetSchedulesRelatedList : function (component, event, helper) {         
        var relatedListEvent = $A.get("e.force:navigateToRelatedList");
        relatedListEvent.setParams({
            "relatedListId": "Asset_Schedules__r",
            "parentRecordId": component.get("v.profileRecordId")
        });
        relatedListEvent.fire();    
    },
    gotoBeneficiariesRelatedList : function (component, event, helper) {         
        var relatedListEvent = $A.get("e.force:navigateToRelatedList");
        relatedListEvent.setParams({
            "relatedListId": "Beneficiaries__r",
            "parentRecordId": component.get("v.profileRecordId")
        });
        relatedListEvent.fire();    
    },
    gotoBusinessDebtSchedulesRelatedList : function (component, event, helper) {         
        var relatedListEvent = $A.get("e.force:navigateToRelatedList");
        relatedListEvent.setParams({
            "relatedListId": "Business_Debt_Schedules__r",
            "parentRecordId": component.get("v.profileRecordId")
        });
        relatedListEvent.fire();    
    },
    gotoFamiliesRelatedList : function (component, event, helper) {         
        var relatedListEvent = $A.get("e.force:navigateToRelatedList");
        relatedListEvent.setParams({
            "relatedListId": "Families__r",
            "parentRecordId": component.get("v.profileRecordId")
        });
        relatedListEvent.fire();    
    },
    gotoInsuranceRelatedList : function (component, event, helper) {         
        var relatedListEvent = $A.get("e.force:navigateToRelatedList");
        relatedListEvent.setParams({
            "relatedListId": "Insurance__r",
            "parentRecordId": component.get("v.profileRecordId")
        });
        relatedListEvent.fire();    
    },
    gotoMaritalRelatedList : function (component, event, helper) {         
        var relatedListEvent = $A.get("e.force:navigateToRelatedList");
        relatedListEvent.setParams({
            "relatedListId": "Marital__r",
            "parentRecordId": component.get("v.profileRecordId")
        });
        relatedListEvent.fire();    
    },*/
    gotoRelatedList : function (component, event, helper) {   
        var elem = event.currentTarget.id;
        console.log("=====elem======"+elem);
        var relatedListEvent = $A.get("e.force:navigateToRelatedList");
        relatedListEvent.setParams({
            "relatedListId": elem,
            "parentRecordId": component.get("v.profileRecordId")
        });
        relatedListEvent.fire();    
    },
    viewRecord : function( component , event , helper) {
        var elem = event.currentTarget.id;
        console.log('element Id is'+event.currentTarget.id);
        var navEvt = $A.get("e.force:navigateToSObject");
        navEvt.setParams({
          "recordId": elem,
          "slideDevName": "detail"
        });
        navEvt.fire();
    },
    
    editRecord : function(component, event, helper) {
        var editRecordEvent = $A.get("e.force:editRecord");
            editRecordEvent.setParams({
             "recordId": component.get("v.profileRecordId")
        });
        editRecordEvent.fire();
	}
    
})