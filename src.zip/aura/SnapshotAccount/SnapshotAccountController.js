({
	doInit : function(component, event, helper) {
        console.log('===in init==='+component.get("v.recordId"));
        component.set("v.loan", "Loans & Leases");
        var action = component.get("c.init");
        action.setParams( {
            "accountId": component.get("v.recordId"),
        });
        action.setCallback(this, function(a) {
            console.log('result===:'+JSON.stringify(a.getReturnValue()));
            component.set("v.AccountWrapObj", a.getReturnValue());
        });
        
        $A.enqueueAction(action); 
	},
    toggle : function(component, event, helper) {
        helper.selectedArticle(component,event);  	     
    }
   
})