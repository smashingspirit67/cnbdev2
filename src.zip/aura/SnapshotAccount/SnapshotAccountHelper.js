({
	selectedArticle : function(component,event) {
		for(var obj in document.getElementsByTagName("article")){
            $A.util.removeClass(document.getElementsByTagName("article")[obj],"selected");
        }
        var types=event.currentTarget.closest("article");
        var tableName="Deposits";
        var accountWrapper=component.get("v.AccountWrapObj");
        if(types.id=="deposit"){
        	accountWrapper.showingRecord=accountWrapper.depositRecord;
            tableName="Deposits";
        }else if(types.id=="lending"){
            accountWrapper.showingRecord=accountWrapper.lendingLeaseRecord;
            tableName="Loans & Leases";
        }else if(types.id=="wealth"){
            accountWrapper.showingRecord=accountWrapper.wealthManagementRecord;
            tableName="Wealth Management";
        }else if(types.id=="service"){
            accountWrapper.showingRecord=accountWrapper.servicesRecord;
            tableName="Services";
        }else if(types.id=="opportunity"){
            accountWrapper.showingRecord=accountWrapper.opportunityRecord;
            tableName="Pipeline";
        }
        component.set("v.AccountWrapObj", accountWrapper);
        $A.util.addClass(types,"selected");
        component.set("v.typeOf",tableName); 
	}
})