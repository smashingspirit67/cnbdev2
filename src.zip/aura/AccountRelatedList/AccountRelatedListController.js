({
	doInit : function(component, event, helper) {
        
        var action1 = component.get("c.init");
            action1.setParams({
                "accountId": component.get("v.recordId"),
                "objectName": "AccountContactRelation",
                "whereColumn": "AccountId"
            });
        action1.setCallback(this, function(a) {
               // window.history.back();
            console.log("===this="+this);
            component.set("v.contactRecords", a.getReturnValue());
            console.log('=====ac1==='+JSON.stringify(a.getReturnValue()));
            });
       var action2 = component.get("c.init");
            action2.setParams({
                "accountId": component.get("v.recordId"),
                "objectName": "Center_Of_Influence__c",
                "whereColumn": "Prospect_or_Client__c"
            });
        action2.setCallback(this, function(a) {
            console.log("===this="+this);
            component.set("v.influenceRecords", a.getReturnValue());
            //console.log(JSON.stringify(a.getReturnValue()));
            });
        var action3 = component.get("c.init");
            action3.setParams({
                "accountId": component.get("v.recordId"),
                "objectName": "Relationship__c",
                "whereColumn": "Account__c"
            });
        action3.setCallback(this, function(a) {
            console.log("===this="+this);
            component.set("v.relationshipRecords", a.getReturnValue());
            //console.log(JSON.stringify(a.getReturnValue()));
            });
        	$A.enqueueAction(action3);
        	$A.enqueueAction(action1);
            $A.enqueueAction(action2);
	},
       createRecord : function (component, event, helper) {
        var createRecordEvent = $A.get("e.force:createRecord");
        createRecordEvent.setParams({
            "entityApiName": "Contact"
        });
        createRecordEvent.fire();
    },
    
    createAccountContactRelation : function (component, event, helper) {
        console.log("===component="+component);
        var createRecordEvent = $A.get("e.force:createRecord");
        createRecordEvent.setParams({
            "entityApiName": "AccountContactRelation"
        });
        createRecordEvent.fire();
    },
    gotoAccountContactRelatedList : function (component, event, helper) {
    var relatedListEvent = $A.get("e.force:navigateToRelatedList");
    relatedListEvent.setParams({
        "relatedListId": "AccountContactRelations",
        "parentRecordId": component.get("v.recordId")
    });
    relatedListEvent.fire();
        console.log("===component2="+component);
	},
    gotoInfluenceRelatedList : function (component, event, helper) {
    var relatedListEvent = $A.get("e.force:navigateToRelatedList");
    relatedListEvent.setParams({
        "relatedListId": "Center_of_Influence_Links__r",
        "parentRecordId": component.get("v.recordId")
    });
    relatedListEvent.fire();
        console.log("===component2="+component);
	},
    gotoRelationshipRelatedList : function (component, event, helper) {
    var relatedListEvent = $A.get("e.force:navigateToRelatedList");
    relatedListEvent.setParams({
        "relatedListId": "Relationships__r",
        "parentRecordId": component.get("v.recordId")
    });
    relatedListEvent.fire();
        console.log("===component2="+component);
	},
    handleSaveSuccess : function (component, event, helper){
        console.log("===component3="+component);
    },
    
    openWindow : function(component, event, helper){
		console.log("===component4="+component);        
       sforce.one.navigatetoURL("/003/e?retURL=%2F0017A00000LI4vk&AccountId=0017A00000LI4vk");
    },
    gotoURL : function (component, event, helper) {
        console.log("===component4="+component); 
    var urlEvent = $A.get("e.force:navigateToURL");
    urlEvent.setParams({
      "url": "/003/e?retURL=0017A00000LI4vk&accid=0017A00000LI4vk"
    });
    urlEvent.fire();
        console.log("===component5="+component); 
	},
    editRecord : function(component, event, helper) {
    var editRecordEvent = $A.get("e.force:editRecord");
    editRecordEvent.setParams({
         "recordId": "0037A00000HvXFdQAN"
   });
    editRecordEvent.fire();
	},
    viewRecord : function (component, event, helper) {
        var elm = event.currentTarget.id;
        console.log("===elm==="+elm);
        var navEvt = $A.get("e.force:navigateToSObject");
        navEvt.setParams({
          "recordId": elm,
          "slideDevName": "detail"
        });
        navEvt.fire();
            
	},
    toggleClass : function (component, event, helper) {
    	var elm = event.currentTarget.id;
        document.getElementById(elm).classList.toggle('slds-is-open');
    },
})