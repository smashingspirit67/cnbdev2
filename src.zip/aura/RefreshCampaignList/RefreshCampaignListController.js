({
	doInit : function(component, event, helper) {
        var action1 = component.get("c.refresh");
            action1.setParams({
                "campaignListId": component.get("v.recordId")
            });
        action1.setCallback(this, function(a) {
            $A.get('e.force:refreshView').fire();
            $A.get("e.force:closeQuickAction").fire();
            });
            
            $A.enqueueAction(action1);
	}
})