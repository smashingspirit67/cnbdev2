({
	init: function(cmp, event, helper) {
        console.log("=======cmp====="+cmp);
        var action = cmp.get("c.getFields");
        action.setParams({
            accountId: cmp.get("v.recordId"),
            typeName: "Profile__c",
            whereColumn: "Prospect_Client__c"
        });
        action.setCallback(this, function(a) {             
            console.log("FieldSetFormController getFields callback");
            var record = a.getReturnValue();
            cmp.set("v.record", record);
        });
        $A.enqueueAction(action);
    },
    toggle : function(component, event, helper) {   
        console.log("==============");
        $A.util.toggleClass(event.currentTarget.parentElement.parentElement, "slds-section slds-is-open");
        
    },
    editRecord : function(component, event, helper) {
        var record=component.get("v.record");
        var editRecordEvent = $A.get("e.force:editRecord");
        editRecordEvent.setParams({
             "recordId": record.profileId
       });
        editRecordEvent.fire();
	},
    refresh : function(component, event, helper) {
        $A.get("e.force:refreshView").fire();
    }
})