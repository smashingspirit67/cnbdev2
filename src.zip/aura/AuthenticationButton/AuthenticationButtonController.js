({
    opencreateCaseinSubtab : function(component, event, helper) {
        debugger;	
        console.debug('Inside');
        var workspaceAPI = component.find("workspace");
         console.debug('workspaceAPI'+workspaceAPI);
        return workspaceAPI.openTab({
            url: '#/sObject/001g000001kt3UQAAY',
            focus: true
        }).then(function(response) {
            console.log("-----",response)
       /* workspaceAPI.focusTab({
            tabId: response
        });*/
    })
        .catch(function(error) {
            console.log(error);
        });
        
    }
})